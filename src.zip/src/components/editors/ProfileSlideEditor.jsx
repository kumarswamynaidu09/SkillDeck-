import React, { useRef, useState } from 'react';
import { MapPin, Camera, Pencil, Check } from 'lucide-react';

export default function ProfileSlideEditor({ data, onUpdate, onSave }) {
  const [previewUrl, setPreviewUrl] = useState(data.avatar_url || '');
  const fileInputRef = useRef(null);

  // Helper to update parent state instantly
  const handleChange = (e) => {
    onUpdate({ [e.target.name]: e.target.value });
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const objectUrl = URL.createObjectURL(file);
      setPreviewUrl(objectUrl);
      // In real app: upload logic here
    }
  };

  return (
    <div className="relative w-full max-w-md h-full max-h-[68vh] rounded-[2.5rem] bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 border border-white/10 flex flex-col overflow-hidden">
      
      <div className="pt-6 pb-2 text-center bg-black/20">
          <h3 className="text-emerald-100 font-semibold text-lg">Edit <span className="text-emerald-400">Profile</span></h3>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pt-4 pb-8 [&::-webkit-scrollbar]:hidden">
        <div className="flex flex-col items-center text-center space-y-6">

          {/* PHOTO */}
          <div className="relative group cursor-pointer" onClick={() => fileInputRef.current.click()}>
            <div className="absolute inset-0 bg-emerald-500 rounded-2xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity" />
            {previewUrl ? (
              <img src={previewUrl} className="relative w-36 h-36 rounded-2xl object-cover border-4 border-white/10 shadow-2xl group-hover:border-emerald-500/50" />
            ) : (
              <div className="relative w-36 h-36 rounded-2xl border-4 border-white/10 bg-white/5 flex flex-col items-center justify-center text-slate-400 group-hover:border-emerald-500/50">
                <Camera className="w-10 h-10 mb-2 opacity-70" />
                <span className="text-xs font-bold uppercase">Upload</span>
              </div>
            )}
            <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
          </div>
          
          {/* INPUTS - Note: value comes from 'data' prop now */}
          <div className="space-y-3 w-full">
            <input
              type="text"
              name="full_name"
              value={data.full_name || ''}
              onChange={handleChange}
              placeholder="Full Name"
              className="text-3xl font-bold text-white bg-transparent text-center w-full focus:outline-none border-b border-emerald-500/50 pb-1"
            />
            <div className="relative max-w-[80%] mx-auto">
                <input 
                  type="text"
                  name="title"
                  value={data.title || ''}
                  onChange={handleChange}
                  placeholder="Job Title"
                  className="text-emerald-400 font-medium text-lg bg-transparent text-center w-full focus:outline-none border-b border-emerald-500/50 pb-1"
                />
                <Pencil className="absolute right-0 top-1 w-4 h-4 text-emerald-400 opacity-50" />
            </div>
            <div className="relative max-w-[70%] mx-auto flex items-center gap-2 text-slate-400">
               <MapPin className="w-3 h-3" />
               <input 
                  type="text"
                  name="location"
                  value={data.location || ''}
                  onChange={handleChange}
                  placeholder="City, Country"
                  className="bg-transparent text-center w-full text-sm focus:outline-none border-b border-slate-500/50 pb-1"
                />
            </div>
          </div>

          <div className="w-full">
            <label className="block text-left text-xs font-bold text-slate-500 uppercase mb-2 ml-2">Needs & Expectations</label>
            <textarea
                name="bio"
                value={data.bio || ''}
                onChange={handleChange}
                rows={4}
                placeholder="Describe your expectations..."
                className="w-full bg-white/5 rounded-xl border border-white/5 p-3 text-slate-300 text-sm focus:outline-none focus:bg-white/10"
              />
          </div>
        </div>
      </div>

      {/* SAVE BUTTON (Added as requested) */}
      <div className="p-4 bg-black/40 border-t border-white/5">
        <button onClick={onSave} className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95">
            <Check className="w-4 h-4" /> Save Profile
        </button>
      </div>

    </div>
  );
}