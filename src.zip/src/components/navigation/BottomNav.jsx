import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, User, MessageSquare } from 'lucide-react';

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 p-4 z-50 pb-6">
      <div className="flex justify-around items-center max-w-md mx-auto">
        <button 
          onClick={() => navigate('/')}
          className={`flex flex-col items-center gap-1 ${isActive('/') ? 'text-blue-500' : 'text-gray-500'}`}
        >
          <Home className="w-6 h-6" />
          <span className="text-xs font-medium">Discover</span>
        </button>

        <button 
          onClick={() => navigate('/matches')}
          className={`flex flex-col items-center gap-1 ${isActive('/matches') ? 'text-blue-500' : 'text-gray-500'}`}
        >
          <MessageSquare className="w-6 h-6" />
          <span className="text-xs font-medium">Matches</span>
        </button>

        <button 
          onClick={() => navigate('/profile')}
          className={`flex flex-col items-center gap-1 ${isActive('/profile') ? 'text-blue-500' : 'text-gray-500'}`}
        >
          <User className="w-6 h-6" />
          <span className="text-xs font-medium">Profile</span>
        </button>
      </div>
    </div>
  );
}