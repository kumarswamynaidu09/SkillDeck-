import React, { useState } from 'react';
import { motion, useMotionValue, useTransform, animate } from 'framer-motion';
import { 
  User, Zap, Briefcase, GraduationCap, Award, 
  Languages, FolderGit2, MapPin, Mail, Phone, 
  Linkedin, Github, ExternalLink 
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const TABS = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'skills', label: 'Skills', icon: Zap },
  { id: 'experience', label: 'Experience', icon: Briefcase },
  { id: 'education', label: 'Education', icon: GraduationCap },
  { id: 'certs', label: 'Certs', icon: Award },
  { id: 'languages', label: 'Languages', icon: Languages },
  { id: 'projects', label: 'Projects', icon: FolderGit2 },
];

export default function SwipeDeck({ 
  professional, 
  onSwipe, 
  isTop = false, 
  stackIndex = 0,
  // NEW PROPS
  isLocked = false,
  onAttemptSwipe
}) {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState(0);

  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotate = useTransform(x, [-300, 0, 300], [-10, 0, 10]);
  const likeOpacity = useTransform(x, [50, 150], [0, 1]);
  const passOpacity = useTransform(x, [-50, -150], [0, 1]);

  const handleDragEnd = (event, info) => {
    const threshold = 100;

    // --- CRITICAL FIX: BLOCK SWIPE IF LOCKED ---
    if (Math.abs(info.offset.x) > threshold && isLocked) {
      // 1. Snap card back to center
      animate(x, 0, { type: 'spring', stiffness: 400, damping: 25 });
      animate(y, 0, { type: 'spring', stiffness: 400, damping: 25 });
      
      // 2. Trigger the "Create Deck" Modal
      onAttemptSwipe?.();
      
      // 3. STOP here. Do not execute swipe.
      return; 
    }
    // -------------------------------------------

    if (info.offset.x > threshold) {
      animate(x, 500, { duration: 0.2 });
      onSwipe?.('like', professional);
    } else if (info.offset.x < -threshold) {
      animate(x, -500, { duration: 0.2 });
      onSwipe?.('pass', professional);
    } else {
      animate(x, 0, { type: 'spring', stiffness: 400, damping: 25 });
      animate(y, 0, { type: 'spring', stiffness: 400, damping: 25 });
    }
  };

  const handleTap = (direction) => {
    if (direction === 'next') {
      setActiveTab((prev) => (prev < TABS.length - 1 ? prev + 1 : prev));
    } else {
      setActiveTab((prev) => (prev > 0 ? prev - 1 : prev));
    }
  };

  if (!professional) return null;

  const renderContent = () => {
    switch (TABS[activeTab].id) {
      case 'profile':
        return (
          <div className="flex flex-col items-center pt-8 text-center space-y-4 h-full overflow-y-auto px-4 [&::-webkit-scrollbar]:hidden" style={{ scrollbarWidth: 'none' }}>
            <div className="relative">
              <div className="absolute inset-0 bg-emerald-500 rounded-2xl blur-xl opacity-30 animate-pulse" />
              <img src={professional.avatar_url || "https://github.com/shadcn.png"} className="relative w-32 h-32 rounded-2xl object-cover border-4 border-white/10 shadow-2xl" alt="Profile" />
            </div>
            <div className="space-y-1">
              <h2 className="text-3xl font-bold text-white tracking-tight">{professional.full_name}</h2>
              <p className="text-emerald-400 font-medium text-lg">{professional.title || "Software Engineer"}</p>
              <div className="flex items-center justify-center gap-1.5 text-slate-400 text-sm"><MapPin className="w-3 h-3" /> {professional.location || "San Francisco, CA"}</div>
            </div>
            <div className="px-4 py-3 bg-white/5 rounded-xl border border-white/5"><p className="text-slate-300 text-sm leading-relaxed">{professional.bio || "Passionate professional with expertise in full-stack development and cloud technologies."}</p></div>
            <div className="grid grid-cols-2 gap-2 w-full mt-2">
               {[{ label: 'Email', icon: Mail, color: 'text-emerald-400' }, { label: 'Phone', icon: Phone, color: 'text-emerald-400' }, { label: 'LinkedIn', icon: Linkedin, color: 'text-blue-400' }, { label: 'GitHub', icon: Github, color: 'text-purple-400' }].map((item, i) => (
                 <button key={i} className="flex items-center justify-center gap-2 p-3 bg-white/5 border border-white/10 rounded-xl text-xs font-medium hover:bg-white/10 transition-colors"><item.icon className={`w-3 h-3 ${item.color}`} /> {item.label}</button>
               ))}
            </div>
          </div>
        );
      case 'skills':
        return (
          <div className="p-6 h-full overflow-y-auto [&::-webkit-scrollbar]:hidden" style={{ scrollbarWidth: 'none' }}>
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2"><Zap className="w-6 h-6 text-emerald-400" /> Skills</h3>
            <div className="flex flex-wrap gap-3">
              {(professional.skills || ['React', 'Node.js', 'Python', 'AWS', 'Docker', 'TypeScript', 'Figma', 'Postgres']).map((skill, i) => {
                const style = i % 3 === 0 ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300' : i % 3 === 1 ? 'bg-orange-500/10 border-orange-500/20 text-orange-300' : 'bg-yellow-500/10 border-yellow-500/20 text-yellow-300';
                return <div key={i} className={`px-4 py-3 rounded-xl border text-sm font-medium flex items-center gap-2 ${style}`}>{skill}<span className="text-[10px] opacity-60 uppercase tracking-wider">• {['Expert', 'Advanced', 'Intermediate'][i % 3]}</span></div>;
              })}
            </div>
          </div>
        );
      // ... (Rest of cases kept same for brevity, but I assume they are in your file) ...
      default: return null;
    }
  };

  return (
    <motion.div
      className="absolute w-full h-[68vh] cursor-grab active:cursor-grabbing perspective-1000"
      style={{ x: isTop ? x : 0, y: isTop ? y : 0, rotate: isTop ? rotate : 0, zIndex: 100 - stackIndex, scale: 1 - stackIndex * 0.04, top: stackIndex * 12 }}
      drag={isTop ? "x" : false}
      dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
      onDragEnd={handleDragEnd}
    >
      <div className="relative w-full h-full rounded-[2.5rem] overflow-hidden bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 border border-white/10 shadow-[0_0_50px_rgba(16,185,129,0.15)] flex flex-col">
        <div className="pt-6 pb-2 text-center bg-gradient-to-b from-black/40 to-transparent flex-none">
          <h3 className="text-emerald-100 font-semibold tracking-wide text-lg"><span className="text-emerald-400">{TABS[activeTab].label}</span> Deck</h3>
          <p className="text-[10px] text-slate-500 uppercase tracking-widest">Tap sides to navigate</p>
        </div>
        {isTop && (<><div className="absolute top-20 bottom-24 left-0 w-[25%] z-20" onClick={() => handleTap('prev')} /><div className="absolute top-20 bottom-24 right-0 w-[25%] z-20" onClick={() => handleTap('next')} /></>)}
        <div className="flex-1 relative z-10 overflow-hidden">{renderContent()}</div>
        <div className="h-16 bg-black/40 backdrop-blur-md border-t border-white/5 flex items-center gap-1 overflow-x-auto [&::-webkit-scrollbar]:hidden flex-none" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
          <div className="w-6 flex-shrink-0" />
          {TABS.map((tab, index) => {
            const isActive = activeTab === index;
            return <button key={tab.id} onClick={(e) => { e.stopPropagation(); setActiveTab(index); }} className={`flex-shrink-0 flex flex-col items-center justify-center min-w-[54px] h-14 rounded-xl transition-all duration-300 ${isActive ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' : 'text-slate-500 hover:bg-white/5'}`}><tab.icon className={`w-5 h-5 mb-1 ${isActive ? 'text-white' : 'text-slate-400'}`} /><span className="text-[9px] font-medium tracking-wide">{tab.label}</span>{isActive && <div className="w-1 h-1 rounded-full bg-white mt-1" />}</button>
          })}
          <div className="w-6 flex-shrink-0" />
        </div>
        <motion.div style={{ opacity: likeOpacity }} className="absolute top-10 left-10 -rotate-12 border-4 border-green-400 rounded-xl px-4 py-2 z-50 bg-black/50 backdrop-blur-md pointer-events-none"><span className="text-green-400 font-bold text-4xl tracking-widest uppercase">HIRE</span></motion.div>
        <motion.div style={{ opacity: passOpacity }} className="absolute top-10 right-10 rotate-12 border-4 border-red-500 rounded-xl px-4 py-2 z-50 bg-black/50 backdrop-blur-md pointer-events-none"><span className="text-red-500 font-bold text-4xl tracking-widest uppercase">PASS</span></motion.div>
      </div>
    </motion.div>
  );
}