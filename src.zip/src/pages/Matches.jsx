import React from 'react';

export default function Matches() {
  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center text-emerald-500">
      <h1 className="text-2xl font-bold">Matches Page (Coming Soon)</h1>
    </div>
  );
}