import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Loader2, Search, Briefcase, Zap, MessageSquare, Send, Users, Sparkles, UserPlus } from 'lucide-react';

// --- FIREBASE ---
import { base44 } from '@/api/base44Client';
import { db } from '@/lib/firebase';
import { doc, setDoc, getDoc, collection, query, where, getDocs, serverTimestamp, onSnapshot } from 'firebase/firestore'; 

// --- DECKS ---
import SwipeDeck from '@/components/decks/SwipeDeck'; 
import CompanyDeck from '@/components/decks/CompanyDeck'; 

// --- THEME COMPONENTS ---
const GlowOrb = ({ color, size, x, y }) => (
  <motion.div
    className="absolute rounded-full blur-3xl pointer-events-none"
    style={{ background: color, width: size, height: size, left: x, top: y }}
    animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.4, 0.2] }}
    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
  />
);

// --- MATCH POPUP ---
const MatchOverlay = ({ professional, onClose, onChat }) => (
  <motion.div 
    initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
    className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/90 backdrop-blur-xl p-6"
  >
    <GlowOrb color="rgba(16, 185, 129, 0.4)" size="300px" x="50%" y="50%" />
    <motion.div 
      initial={{ scale: 0.5, rotate: -10 }} animate={{ scale: 1, rotate: 0 }}
      transition={{ type: "spring", bounce: 0.5 }}
      className="relative mb-8"
    >
      <div className="absolute inset-0 bg-emerald-500 rounded-full blur-xl opacity-50 animate-pulse" />
      <img src={professional.avatar_url} className="relative w-32 h-32 rounded-full border-4 border-emerald-400 object-cover shadow-2xl" />
    </motion.div>
    <h2 className="text-4xl font-black text-white text-center mb-2 italic">IT'S A MATCH!</h2>
    <p className="text-slate-400 text-center mb-8 max-w-xs">You and <span className="text-emerald-400 font-bold">{professional.full_name}</span> like each other.</p>
    <div className="flex flex-col gap-3 w-full max-w-xs">
      <button onClick={onChat} className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20">
        <Send className="w-5 h-5" /> Send Message
      </button>
      <button onClick={onClose} className="w-full py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-2xl">Keep Swiping</button>
    </div>
  </motion.div>
);

// --- NEW: CREATE DECK MODAL ---
const CreateDeckModal = ({ onClose, onGoToProfile }) => (
  <motion.div 
    initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
    className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/90 backdrop-blur-md p-6"
  >
    <motion.div 
      initial={{ scale: 0.8, y: 20 }} animate={{ scale: 1, y: 0 }}
      className="bg-slate-900 border border-emerald-500/30 p-8 rounded-3xl max-w-sm w-full text-center relative overflow-hidden"
    >
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-green-300" />
      <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
        <UserPlus className="w-10 h-10 text-emerald-400" />
      </div>
      <h2 className="text-2xl font-bold text-white mb-2">Create Your Deck</h2>
      <p className="text-slate-400 mb-8 leading-relaxed">
        You need a profile deck before you can match with others. It only takes a minute!
      </p>
      <button 
        onClick={onGoToProfile}
        className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-xl transition-all shadow-lg shadow-emerald-500/20"
      >
        Build My Deck
      </button>
      <button onClick={onClose} className="mt-4 text-slate-500 text-sm hover:text-white transition-colors">
        Take a look around first
      </button>
    </motion.div>
  </motion.div>
);

export default function Home() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  
  // --- CHANGED: Use a Ref for strict duplicate blocking ---
  const swipedSet = useRef(new Set());
  const [swipedIds, setSwipedIds] = useState([]); // Keep for React re-renders

  const [activeTab, setActiveTab] = useState('home');
  const [matchPopup, setMatchPopup] = useState(null);
  const [professionals, setProfessionals] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showDeckModal, setShowDeckModal] = useState(false);
  const [viewMode, setViewMode] = useState('discover'); 
  const [incomingLikes, setIncomingLikes] = useState([]);

  // 1. CHECK AUTH
  useEffect(() => {
    base44.auth.me()
      .then(u => {
        setUser(u);
        if (!u.onboarding_completed) navigate('/onboarding');
      })
      .catch(() => navigate('/login'));
  }, [navigate]);

  // 2. FETCH INCOMING LIKES
  useEffect(() => {
    if (!user) return;
    const fetchLikes = async () => {
      const q = query(
        collection(db, "swipes"), 
        where("to", "==", user.id), 
        where("type", "==", "like")
      );
      const snapshot = await getDocs(q);
      const likedBy = snapshot.docs.map(doc => doc.data().from);
      setIncomingLikes(likedBy);
    };
    fetchLikes();
  }, [user]);

  // 3. REAL-TIME DATA LISTENER (With Duplicate Protection)
  useEffect(() => {
    if (!user) return;

    // Listen to database changes in real-time
    const unsubscribe = onSnapshot(collection(db, "users"), (snapshot) => {
        // Map docs to a clean array
        const docs = snapshot.docs
          .map(doc => ({ id: doc.id, ...doc.data() }))
          // CRITICAL FIX: Filter out anyone we have EVER swiped in this session
          .filter(doc => !swipedSet.current.has(doc.id));
        
        // Update state
        setProfessionals(docs);
        setIsLoading(false);
    });

    // Cleanup when leaving page
    return () => unsubscribe();
  }, [user]);

  const filteredProfessionals = user ? professionals
    .filter(prof => prof.id !== user.id) // Ensure I never see myself
    // Double protection: Filter against local state too
    .filter(prof => !swipedIds.includes(prof.id))
    .filter(prof => {
      const targetRole = user.user_type === 'seeker' ? 'recruiter' : 'seeker';
      if (prof.user_type !== targetRole) return false;
      
      if (viewMode === 'applicants') {
        return incomingLikes.includes(prof.id);
      } else {
        const userIndustry = user.industry || 'Any'; 
        if (userIndustry === 'Any') return true;
        return prof.industry === userIndustry;
      }
    }) : [];

  const handleSwipe = async (action, professional) => {
    // 1. BLOCK DUPLICATES IMMEDIATELY
    swipedSet.current.add(professional.id);
    setSwipedIds(prev => [...prev, professional.id]);
    
    // 2. Remove from UI immediately so it can't be seen again
    setProfessionals(prev => prev.filter(p => p.id !== professional.id));

    if (!user) return;
    
    const myId = user.id;
    const theirId = professional.id;

    try {
      await setDoc(doc(db, "swipes", `${myId}_${theirId}`), {
        from: myId, to: theirId, type: action, timestamp: serverTimestamp()
      });

      if (action === 'like') {
        const reverseSwipeRef = doc(db, "swipes", `${theirId}_${myId}`);
        const reverseSnap = await getDoc(reverseSwipeRef);
        
        if (viewMode === 'applicants' || (reverseSnap.exists() && reverseSnap.data().type === 'like')) {
          const matchId = [myId, theirId].sort().join('_');
          await setDoc(doc(db, "matches", matchId), {
            users: [myId, theirId],
            user_details: {
                [myId]: { name: user.full_name, avatar: user.avatar_url },
                [theirId]: { name: professional.full_name, avatar: professional.avatar_url }
            },
            timestamp: serverTimestamp(),
            last_message: "New Match!"
          });
          setMatchPopup(professional);
        }
      }
    } catch (error) {
      console.error("Swipe error:", error);
    }
  };

  if (!user || isLoading) {
    return (
      <div className="min-h-screen w-full bg-slate-950 flex flex-col items-center justify-center font-sans">
        <Loader2 className="w-10 h-10 text-emerald-500 animate-spin" />
        <p className="text-emerald-500/50 mt-4 text-sm font-medium animate-pulse">Syncing SkillDeck...</p>
      </div>
    );
  }

  const isRecruiter = user.user_type === 'recruiter';
  const isDeckReady = user.deck_created === true;

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-950 via-emerald-950 to-slate-900 relative overflow-hidden font-sans text-white">
      <AnimatePresence>
        {matchPopup && <MatchOverlay professional={matchPopup} onClose={() => setMatchPopup(null)} onChat={() => { setMatchPopup(null); navigate('/chat'); }} />}
        
        {showDeckModal && (
          <CreateDeckModal 
            onClose={() => setShowDeckModal(false)}
            onGoToProfile={() => navigate('/profile')}
          />
        )}
      </AnimatePresence>

      <div className="absolute inset-0 bg-[linear-gradient(rgba(16,185,129,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(16,185,129,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />
      <GlowOrb color="rgba(16, 185, 129, 0.2)" size="500px" x="50%" y="-20%" />

      {/* HEADER */}
      <div className="absolute top-0 left-0 right-0 pt-14 px-6 pb-4 z-40 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-white via-emerald-200 to-green-200 bg-clip-text text-transparent">SkillDeck</h1>
          <p className="text-xs text-slate-400 font-medium tracking-wide uppercase">
            {isRecruiter ? 'Find Talent' : 'Find Work'}
          </p>
        </div>
        <button onClick={() => navigate('/profile')} className="relative group">
          <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur group-hover:bg-emerald-500/40 transition-all" />
          <img src={user.avatar_url} className="w-10 h-10 rounded-full border border-white/20 relative z-10 bg-slate-900 object-cover" />
        </button>
      </div>

      {/* VIEW TOGGLE */}
      <div className="relative z-30 px-6 mt-24 mb-4 max-w-md mx-auto">
        <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-1 flex relative">
          <motion.div 
            className="absolute top-1 bottom-1 bg-emerald-500 rounded-lg shadow-lg shadow-emerald-500/20"
            initial={false}
            animate={{ 
              left: viewMode === 'discover' ? '4px' : '50%', 
              width: 'calc(50% - 6px)' 
            }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          />
          <button onClick={() => setViewMode('discover')} className={`flex-1 relative z-10 py-2 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${viewMode === 'discover' ? 'text-black font-bold' : 'text-slate-400 hover:text-white'}`}>
            <Sparkles className="w-4 h-4" /> Discover
          </button>
          <button onClick={() => setViewMode('applicants')} className={`flex-1 relative z-10 py-2 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${viewMode === 'applicants' ? 'text-black font-bold' : 'text-slate-400 hover:text-white'}`}>
            <Users className="w-4 h-4" /> 
            {isRecruiter ? 'Applicants' : 'Interested'}
            {incomingLikes.length > 0 && viewMode !== 'applicants' && <span className="absolute top-1 right-3 w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />}
          </button>
        </div>
      </div>

      {/* MAIN CARD STACK */}
      <div className="relative z-10 h-[68vh] flex items-center justify-center p-4 max-w-md w-full mx-auto">
        <AnimatePresence mode='wait'>
          {filteredProfessionals.length > 0 ? (
            filteredProfessionals.map((prof, index) => {
              if (index > 1) return null; 

              if (isRecruiter) {
                return (
                  <SwipeDeck
                    key={prof.id}
                    professional={prof}
                    onSwipe={handleSwipe}
                    isTop={index === 0}
                    stackIndex={index}
                    isLocked={!isDeckReady} 
                    onAttemptSwipe={() => setShowDeckModal(true)}
                  />
                );
              } else {
                return (
                  <CompanyDeck
                    key={prof.id}
                    company={prof}
                    onSwipe={handleSwipe}
                    isTop={index === 0}
                    stackIndex={index}
                    isLocked={!isDeckReady} 
                    onAttemptSwipe={() => setShowDeckModal(true)}
                  />
                );
              }
            }).reverse()
          ) : (
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center p-8 max-w-sm backdrop-blur-xl bg-white/[0.03] border border-white/[0.1] rounded-3xl">
              <div className="relative w-32 h-32 mx-auto mb-6">
                <div className="absolute inset-0 bg-emerald-500/20 rounded-full animate-ping" />
                <div className="relative bg-slate-900 border border-emerald-500/30 w-32 h-32 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(16,185,129,0.2)]">
                  <Search className="w-12 h-12 text-emerald-400" />
                </div>
              </div>
              <h2 className="text-xl font-bold text-white mb-2">
                {viewMode === 'applicants' ? 'No New Interest' : 'All Caught Up!'}
              </h2>
              <p className="text-slate-400 text-sm mb-6">
                 {isRecruiter ? "No more candidates in this area." : "No more jobs match your criteria."}
              </p>
              <button onClick={() => { setSwipedIds([]); refetch(); }} className="w-full py-3 bg-white/[0.05] border border-white/[0.1] hover:bg-white/[0.1] rounded-xl text-emerald-300 text-sm font-medium transition-all">
                Review Passed Profiles
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* FOOTER NAV */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-40 w-full max-w-[280px]">
         <div className="flex justify-between items-center px-6 py-3 bg-slate-900/60 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl shadow-black/50">
            <button onClick={() => setActiveTab('home')} className={`flex flex-col items-center gap-1 transition-all ${activeTab === 'home' ? 'text-emerald-400 scale-110' : 'text-slate-500 hover:text-slate-300'}`}>
              <Briefcase className="w-6 h-6" />
              <span className="text-[10px] font-medium">Feed</span>
            </button>
            <button onClick={() => { setActiveTab('matches'); navigate('/matches'); }} className={`flex flex-col items-center gap-1 transition-all ${activeTab === 'matches' ? 'text-emerald-400 scale-110' : 'text-slate-500 hover:text-slate-300'}`}>
              <Zap className="w-6 h-6" />
              <span className="text-[10px] font-medium">Matches</span>
            </button>
            <button onClick={() => { setActiveTab('chat'); navigate('/chat'); }} className={`flex flex-col items-center gap-1 transition-all ${activeTab === 'chat' ? 'text-emerald-400 scale-110' : 'text-slate-500 hover:text-slate-300'}`}>
              <MessageSquare className="w-6 h-6" />
              <span className="text-[10px] font-medium">Chat</span>
            </button>
         </div>
      </div>
    </div>
  );
}