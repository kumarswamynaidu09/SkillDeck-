import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Loader2, Save } from 'lucide-react';
import { doc, getDoc, setDoc } from 'firebase/firestore'; // CHANGED: Imported setDoc
import { db, auth } from '@/lib/firebase'; 
import { User, Zap, Briefcase, GraduationCap, Award, Languages, FolderGit2 } from 'lucide-react';

import ProfileSlideEditor from '@/components/editors/ProfileSlideEditor';
import SkillsSlideEditor from '@/components/editors/SkillsSlideEditor';
import CompanySlideEditor from '@/components/editors/CompanySlideEditor';

const TABS = [{ id: 'profile', label: 'Profile', icon: User }, { id: 'skills', label: 'Skills', icon: Zap }, { id: 'experience', label: 'Experience', icon: Briefcase }, { id: 'education', label: 'Education', icon: GraduationCap }, { id: 'certs', label: 'Certs', icon: Award }, { id: 'languages', label: 'Languages', icon: Languages }, { id: 'projects', label: 'Projects', icon: FolderGit2 }];

export default function DeckEditorLayout() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState({}); 
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('profile'); 
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      if (!auth.currentUser) return;
      try {
        const snap = await getDoc(doc(db, "users", auth.currentUser.uid));
        if (snap.exists()) setUserData(snap.data());
      } catch (err) { console.error(err); } finally { setLoading(false); }
    };
    fetchUser();
  }, []);

  const handleLocalUpdate = (partialData) => setUserData(prev => ({ ...prev, ...partialData }));
  
  // --- THE FIX: STRICT SAVE LOGIC ---
  const handleSaveToDb = async () => {
    if (!auth.currentUser) return;
    setIsSaving(true);
    try {
      // CHANGED: setDoc with { merge: true } is safer.
      // It forces the ID to be the user's UID and merges data, preventing duplicates.
      await setDoc(doc(db, "users", auth.currentUser.uid), { 
        ...userData, 
        deck_created: true, 
        updated_at: new Date() 
      }, { merge: true });
      
      setTimeout(() => setIsSaving(false), 800); 
      alert("Deck Saved!");
    } catch (error) { 
      console.error(error);
      alert("Save Failed"); 
      setIsSaving(false); 
    }
  };

  const renderEditor = () => {
    const safeData = userData || {};
    const props = { data: safeData, onUpdate: handleLocalUpdate, onSave: handleSaveToDb };
    if (safeData.user_type === 'recruiter' && activeTab === 'profile') return <CompanySlideEditor {...props} />;
    switch (activeTab) {
      case 'profile': return <ProfileSlideEditor {...props} />;
      case 'skills': return <SkillsSlideEditor {...props} />;
      default: return <div className="text-slate-500 pt-20">Coming Soon</div>;
    }
  };

  if (loading) return <div className="min-h-screen bg-slate-950 flex items-center justify-center"><Loader2 className="w-8 h-8 text-emerald-500 animate-spin" /></div>;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col">
      <div className="h-16 px-4 flex items-center justify-between bg-black/20 backdrop-blur-md border-b border-white/5 z-20">
        <button onClick={() => navigate('/profile')} className="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 text-slate-300"><ChevronLeft className="w-6 h-6" /></button>
        <h2 className="text-white font-bold capitalize">{activeTab} Editor</h2>
        <button onClick={handleSaveToDb} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider rounded-full transition-all">{isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}{isSaving ? 'Saving...' : 'Save All'}</button>
      </div>
      <div className="flex-1 flex items-center justify-center p-4 relative z-10">{renderEditor()}</div>
      <div className="h-[88px] bg-black/40 backdrop-blur-xl border-t border-white/5 flex items-center px-4 gap-2 overflow-x-auto scrollbar-hide z-30">
        <div className="w-2 flex-shrink-0" />
        {TABS.map((tab, index) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex-shrink-0 flex flex-col items-center justify-center w-[60px] h-[64px] rounded-2xl transition-all ${activeTab === tab.id ? 'bg-emerald-500 text-white' : 'text-slate-500 hover:bg-white/5'}`}>
              <tab.icon className="w-5 h-5 mb-1" />
              <span className="text-[9px] font-medium">{tab.label}</span>
            </button>
          ))}
        <div className="w-4 flex-shrink-0" />
      </div>
    </div>
  );
}