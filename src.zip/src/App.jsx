import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// --- EXISTING IMPORTS ---
import Login from './pages/Login';
import Onboarding from './pages/Onboarding';
import Home from './pages/Home';
import Profile from './pages/Profile';
import Matches from './pages/Matches';
import Chat from './pages/Chat';

// --- NEW IMPORT (YOU MISSED THIS) ---
import DeckEditorLayout from './pages/DeckEditorLayout'; 

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/onboarding" element={<Onboarding />} />
          
          {/* Main App */}
          <Route path="/" element={<Home />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/matches" element={<Matches />} />
          <Route path="/chat" element={<Chat />} />

          {/* --- NEW ROUTE (YOU MISSED THIS) --- */}
          <Route path="/deck-editor" element={<DeckEditorLayout />} />

        </Routes>
      </Router>
    </QueryClientProvider>
  );
}

export default App;